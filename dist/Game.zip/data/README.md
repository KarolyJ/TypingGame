# TypingGame
A game made with python
