WIDTH = 900
HEIGHT = 600
FPS = 30

# RGB values of standard colors
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
GREEN = (0, 255, 0)
RED = (255, 0, 0)

# importing words from the txt file
file = open("data/words.txt", "r")
data = file.readlines()
file.close()


